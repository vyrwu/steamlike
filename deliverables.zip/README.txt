The following directory contains all deliverables required, which includes:

- steamlike Windows executable file (.exe)
-- no OSX executable included. No installation or configuration needed.  

- steamlike source code package (.zip)
-- source-code can also be found here: https://github.com/vyrwu/steamlike/tree/BETA-v1.0

- steamlike teaser movie (.mp4)

Please note that compiling the source code requires Game Maker Studio 2.
